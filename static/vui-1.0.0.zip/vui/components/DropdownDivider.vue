<template>
	<div class="dropdown-divider"></div>
</template>

<script>
export default {
	name: 'vui-dropdown-divider'
}
</script>