<template>
	<span class="dropdown-item-text">
		<slot></slot>
	</span>
</template>

<script>
export default {
	name: 'vui-dropdown-item-text'
}
</script>