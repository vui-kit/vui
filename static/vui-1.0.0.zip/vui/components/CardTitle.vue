<template>
	<h5 class="card-title">
		<slot></slot>
	</h5>
</template>

<script>
export default {
	name: 'vui-card-title'
}
</script>