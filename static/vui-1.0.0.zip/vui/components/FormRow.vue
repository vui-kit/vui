<template>
	<div class="form-row">
		<slot></slot>
	</div>
</template>

<script>
export default {
	name: 'vui-form-row'
}
</script>