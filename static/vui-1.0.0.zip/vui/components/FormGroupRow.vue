<template>
	<div class="form-group row">
		<slot></slot>
	</div>
</template>

<script>
export default {
	name: 'vui-form-group-row'
}
</script>