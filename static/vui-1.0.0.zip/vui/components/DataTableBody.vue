<template>
	<tbody class="tbody">
		<slot></slot>
	</tbody>
</template>

<script>
export default {
	name: 'vui-data-table-body'
}
</script>