<template>
	<tr>
		<slot></slot>
	</tr>
</template>

<script>
export default {
	name: 'vui-data-table-row'
}
</script>