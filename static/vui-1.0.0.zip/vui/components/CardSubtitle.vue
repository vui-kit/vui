<template>
	<h6 class="card-subtitle mb-2 text-muted">
		<slot></slot>
	</h6>
</template>

<script>
export default {
	name: 'vui-card-subtitle'
}
</script>