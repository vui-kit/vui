<template>
	<small class="form-text text-muted">
		<slot></slot>
	</small>
</template>

<script>
export default {
	name: 'vui-form-help-text'
}
</script>

<style>

</style>
