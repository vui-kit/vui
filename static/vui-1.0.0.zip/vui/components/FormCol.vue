<template>
	<div class="col">
		<slot></slot>
	</div>
</template>

<script>
export default {
	name: 'vui-form-col'
}
</script>