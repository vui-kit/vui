<template>
	<select class="form-control">
		<slot></slot>
</select>
</template>

<script>
export default {
	name: 'vui-select',
	props: {

	}
}
</script>

<style>

</style>
