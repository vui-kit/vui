<template>
	<h6 class="dropdown-header">
		<slot></slot>
	</h6>
</template>

<script>
export default {
	name: 'vui-dropdown-header'
}
</script>