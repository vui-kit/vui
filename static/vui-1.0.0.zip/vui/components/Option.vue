<template>
	<option>
		<slot></slot>
	</option>
</template>

<script>
export default {
	name: 'vui-option'
}
</script>

<style scoped>
option {
	padding-top: .3rem !important;
	padding-bottom: .3rem !important;
}
</style>
