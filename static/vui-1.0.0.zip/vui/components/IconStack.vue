<template>
	<span class="icon-stack">
		<slot></slot>
	</span>
</template>

<script>
export default {
	name: 'vui-icon-stack'
}
</script>