<template>
	<span class="navbar-text">
   <slot></slot>
  </span>
</template>

<script>
export default {
	name: 'vui-navbar-text'
}
</script>