<template>
	<p class="card-text">
		<slot></slot>
	</p>
</template>

<script>
export default {
	name: 'vui-card-text'
}
</script>